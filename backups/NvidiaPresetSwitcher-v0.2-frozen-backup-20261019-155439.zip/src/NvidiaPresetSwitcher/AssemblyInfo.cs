using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NVIDIA 颜色预设切换器")]
[assembly: AssemblyDescription("保存和快速切换 NVIDIA App 系统颜色设置")]
[assembly: AssemblyCompany("Local Build")]
[assembly: AssemblyProduct("NVIDIA 颜色预设切换器")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: ComVisible(false)]
[assembly: Guid("ca2e694f-a912-40f5-8b8e-649f43071bd0")]
[assembly: AssemblyVersion("0.2.0.0")]
[assembly: AssemblyFileVersion("0.2.0.0")]
