using System;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace NvidiaPresetSwitcher
{
    internal static class Program
    {
        [STAThread]
        private static int Main(string[] args)
        {
            if (args.Length > 0 && args[0] == "--diagnose")
            {
                try
                {
                    DisplayColorService service = new DisplayColorService();
                    Console.WriteLine(service.DescribeCurrent());
                    ColorPreset snapshot = service.Capture("diagnostic");
                    Console.WriteLine("Displays=" + snapshot.Displays.Count + ", RegistryColorKeys=" + snapshot.RegistryColors.Count);
                    for (int i = 0; i < snapshot.Displays.Count; i++)
                    {
                        DisplaySnapshot d = snapshot.Displays[i];
                        Console.WriteLine("Ramp[{0}]={1} bytes", d.DeviceName, String.IsNullOrEmpty(d.GammaRampBase64) ? 0 : Convert.FromBase64String(d.GammaRampBase64).Length);
                    }
                    if (args.Length > 1 && args[1] == "--apply-current")
                    {
                        ApplyResult applied = service.Apply(snapshot);
                        Console.WriteLine("ApplyCurrent=" + (applied.Success ? "OK" : String.Join(" | ", applied.Messages.ToArray())));
                    }
                    return 0;
                }
                catch (Exception ex) { Console.Error.WriteLine(ex); return 1; }
            }

            bool startHidden = args.Any(delegate(string arg) { return String.Equals(arg, "--startup", StringComparison.OrdinalIgnoreCase); });

            bool created;
            using (Mutex mutex = new Mutex(true, "NvidiaPresetSwitcher.SingleInstance", out created))
            {
                if (!created)
                {
                    MessageBox.Show("NVIDIA 颜色预设切换器已经在后台运行。\n按 Ctrl+Alt+0 可调出工具面板。", "程序已运行", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return 0;
                }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                try
                {
                    string startupError;
                    StartupService.TryEnsureEnabled(Application.ExecutablePath, out startupError);
                    Application.Run(new MainForm(startHidden, startupError));
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "启动失败", MessageBoxButtons.OK, MessageBoxIcon.Error); return 1; }
                return 0;
            }
        }
    }
}
