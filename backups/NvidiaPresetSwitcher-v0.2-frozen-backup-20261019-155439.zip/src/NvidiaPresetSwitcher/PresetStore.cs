using System;
using System.IO;
using System.Runtime.Serialization.Json;

namespace NvidiaPresetSwitcher
{
    internal sealed class PresetStore
    {
        private readonly string _directory;
        private readonly string _path;

        public PresetStore()
        {
            _directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NvidiaPresetSwitcher");
            _path = Path.Combine(_directory, "presets.json");
        }

        public string FilePath { get { return _path; } }

        public PresetCollection Load()
        {
            if (!File.Exists(_path)) return new PresetCollection();
            try
            {
                using (FileStream stream = File.OpenRead(_path))
                {
                    DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(PresetCollection));
                    PresetCollection data = serializer.ReadObject(stream) as PresetCollection;
                    return data ?? new PresetCollection();
                }
            }
            catch
            {
                string backup = _path + ".broken-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
                File.Copy(_path, backup, true);
                return new PresetCollection();
            }
        }

        public void Save(PresetCollection data)
        {
            Directory.CreateDirectory(_directory);
            string temp = _path + ".tmp";
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(PresetCollection));
            using (FileStream stream = File.Create(temp)) serializer.WriteObject(stream, data);

            if (File.Exists(_path))
            {
                string backup = _path + ".bak";
                File.Copy(_path, backup, true);
                File.Delete(_path);
            }
            File.Move(temp, _path);
        }
    }
}
