using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace NvidiaPresetSwitcher
{
    internal sealed class MainForm : Form
    {
        private const int WmHotkey = 0x0312;
        private const int PanelHotkeyId = 900;
        private const uint ModAlt = 0x0001;
        private const uint ModControl = 0x0002;
        private const int WsExToolWindow = 0x00000080;

        [DllImport("user32.dll")] private static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint virtualKey);
        [DllImport("user32.dll")] private static extern bool UnregisterHotKey(IntPtr window, int id);

        private readonly PresetStore _store;
        private readonly DisplayColorService _colors;
        private PresetCollection _data;
        private readonly ListBox _list;
        private readonly Label _current;
        private readonly Label _status;
        private readonly string _startupWarning;
        private bool _forceClose;
        private bool _allowVisible;

        public MainForm(bool startHidden, string startupWarning)
        {
            _store = new PresetStore();
            _colors = new DisplayColorService();
            _data = _store.Load();
            _startupWarning = startupWarning;

            Text = "NVIDIA 颜色预设切换器";
            StartPosition = FormStartPosition.CenterScreen;
            ShowInTaskbar = false;
            MinimumSize = new Size(720, 500);
            ClientSize = new Size(820, 540);
            Font = new Font("Microsoft YaHei UI", 9F);
            BackColor = Color.FromArgb(242, 244, 247);

            Panel header = new Panel { Dock = DockStyle.Top, Height = 76, BackColor = Color.FromArgb(30, 34, 40) };
            Label title = new Label { Text = "NVIDIA 颜色预设", ForeColor = Color.White, Font = new Font(Font.FontFamily, 18F, FontStyle.Bold), AutoSize = true, Location = new Point(24, 14) };
            Label sub = new Label { Text = "保存 NVIDIA App → 系统 → 颜色，并一键恢复", ForeColor = Color.FromArgb(185, 190, 198), AutoSize = true, Location = new Point(27, 48) };
            header.Controls.Add(title);
            header.Controls.Add(sub);

            Panel currentPanel = new Panel { Dock = DockStyle.Top, Height = 104, Padding = new Padding(24, 14, 24, 10), BackColor = Color.White };
            Label currentTitle = new Label { Text = "当前 NVIDIA 颜色状态", Font = new Font(Font, FontStyle.Bold), AutoSize = true, Location = new Point(24, 13) };
            _current = new Label { Text = "正在读取…", AutoSize = false, Location = new Point(24, 40), Size = new Size(620, 56), ForeColor = Color.FromArgb(70, 74, 82) };
            Button refresh = NewButton("刷新读取", 674, 34, 112);
            refresh.Click += delegate { RefreshCurrent(); };
            currentPanel.Controls.Add(currentTitle);
            currentPanel.Controls.Add(_current);
            currentPanel.Controls.Add(refresh);
            currentPanel.Resize += delegate { refresh.Left = currentPanel.ClientSize.Width - refresh.Width - 24; _current.Width = refresh.Left - 40; };

            Panel body = new Panel { Dock = DockStyle.Fill, Padding = new Padding(24, 18, 24, 18) };
            Label listTitle = new Label { Text = "我的预设", Font = new Font(Font.FontFamily, 11F, FontStyle.Bold), AutoSize = true, Location = new Point(24, 18) };
            _list = new ListBox { Location = new Point(24, 50), IntegralHeight = false, BorderStyle = BorderStyle.FixedSingle, Font = new Font(Font.FontFamily, 11F), ItemHeight = 34 };
            _list.DoubleClick += delegate { ApplySelected(); };
            Button create = NewButton("保存当前为新预设", 0, 0, 150);
            Button apply = NewButton("应用", 0, 0, 88);
            Button rename = NewButton("重命名", 0, 0, 88);
            Button delete = NewButton("删除", 0, 0, 88);
            Button exit = NewButton("退出程序", 0, 0, 96);
            create.BackColor = Color.FromArgb(118, 185, 0);
            create.ForeColor = Color.White;
            create.FlatAppearance.BorderSize = 0;
            create.Click += delegate { CreatePreset(); };
            apply.Click += delegate { ApplySelected(); };
            rename.Click += delegate { RenameSelected(); };
            delete.Click += delegate { DeleteSelected(); };
            exit.BackColor = Color.FromArgb(238, 240, 243);
            exit.Click += delegate { _forceClose = true; Close(); };
            body.Controls.Add(listTitle);
            body.Controls.Add(_list);
            body.Controls.Add(create);
            body.Controls.Add(apply);
            body.Controls.Add(rename);
            body.Controls.Add(delete);
            body.Controls.Add(exit);

            _status = new Label { Dock = DockStyle.Bottom, Height = 30, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(24, 0, 0, 0), BackColor = Color.FromArgb(226, 230, 235), ForeColor = Color.FromArgb(60, 65, 73) };

            body.Resize += delegate
            {
                int buttonTop = body.ClientSize.Height - 48;
                _list.Size = new Size(body.ClientSize.Width - 48, buttonTop - 58);
                create.Location = new Point(24, buttonTop);
                apply.Location = new Point(184, buttonTop);
                rename.Location = new Point(282, buttonTop);
                delete.Location = new Point(380, buttonTop);
                exit.Location = new Point(body.ClientSize.Width - exit.Width - 24, buttonTop);
            };

            Controls.Add(body);
            Controls.Add(_status);
            Controls.Add(currentPanel);
            Controls.Add(header);

            Resize += delegate { if (WindowState == FormWindowState.Minimized) Hide(); };
            FormClosing += OnFormClosing;
            Shown += delegate { RefreshList(); RefreshCurrent(); ShowStartupWarning(); };
            _allowVisible = !startHidden;
            if (startHidden)
            {
                RefreshList();
                RefreshCurrent();
                ShowStartupWarning();
            }

            IntPtr createHiddenMessageWindow = Handle;
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams parameters = base.CreateParams;
                parameters.ExStyle |= WsExToolWindow;
                return parameters;
            }
        }

        protected override void SetVisibleCore(bool value)
        {
            if (value && !_allowVisible) value = false;
            base.SetVisibleCore(value);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            RegisterPresetHotkeys();
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            UnregisterPresetHotkeys();
            base.OnHandleDestroyed(e);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WmHotkey)
            {
                if (m.WParam.ToInt32() == PanelHotkeyId)
                {
                    ToggleWindow();
                    base.WndProc(ref m);
                    return;
                }
                int index = m.WParam.ToInt32() - 1000;
                if (index >= 0 && index < _data.Presets.Count) ApplyPreset(_data.Presets[index]);
            }
            base.WndProc(ref m);
        }

        private static Button NewButton(string text, int left, int top, int width)
        {
            return new Button { Text = text, Location = new Point(left, top), Width = width, Height = 34, FlatStyle = FlatStyle.Flat, BackColor = Color.White, ForeColor = Color.FromArgb(40, 44, 50) };
        }

        private void ShowStartupWarning()
        {
            if (!String.IsNullOrWhiteSpace(_startupWarning))
                _status.Text = "开机自启配置未完成：" + _startupWarning;
        }

        private void RefreshCurrent()
        {
            try { _current.Text = _colors.DescribeCurrent(); _status.Text = "已读取当前设置"; }
            catch (Exception ex) { _current.Text = "读取失败：" + ex.Message; _status.Text = "请确认显示器由 NVIDIA GPU 驱动"; }
        }

        private void RefreshList()
        {
            string selectedId = (_list.SelectedItem as ColorPreset) == null ? null : ((ColorPreset)_list.SelectedItem).Id;
            _list.BeginUpdate();
            _list.Items.Clear();
            for (int i = 0; i < _data.Presets.Count; i++) _list.Items.Add(_data.Presets[i]);
            _list.EndUpdate();
            for (int i = 0; i < _list.Items.Count; i++) if (((ColorPreset)_list.Items[i]).Id == selectedId) _list.SelectedIndex = i;
            if (_list.SelectedIndex < 0 && _list.Items.Count > 0) _list.SelectedIndex = 0;
            RegisterPresetHotkeys();
        }

        private void CreatePreset()
        {
            using (PromptDialog dialog = new PromptDialog("新建预设", "为当前 NVIDIA 颜色设置命名：", ""))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK || dialog.Value.Length == 0) return;
                if (NameExists(dialog.Value, null)) { MessageBox.Show(this, "预设名称已存在。", "名称重复", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
                try
                {
                    ColorPreset preset = _colors.Capture(dialog.Value);
                    _data.Presets.Add(preset);
                    _store.Save(_data);
                    RefreshList();
                    _list.SelectedItem = preset;
                    _status.Text = "已保存预设“" + preset.Name + "”";
                }
                catch (Exception ex) { ShowError("保存预设失败", ex); }
            }
        }

        private void ApplySelected()
        {
            ColorPreset preset = _list.SelectedItem as ColorPreset;
            if (preset != null) ApplyPreset(preset);
        }

        private void ApplyPreset(ColorPreset preset)
        {
            try
            {
                ApplyResult result = _colors.Apply(preset);
                if (result.Success)
                {
                    _status.Text = "已应用预设“" + preset.Name + "”";
                    RefreshCurrent();
                }
                else MessageBox.Show(this, String.Join(Environment.NewLine, result.Messages.ToArray()), "部分设置应用失败", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex) { ShowError("应用预设失败", ex); }
        }

        private void RenameSelected()
        {
            ColorPreset preset = _list.SelectedItem as ColorPreset;
            if (preset == null) return;
            using (PromptDialog dialog = new PromptDialog("重命名预设", "新的预设名称：", preset.Name))
            {
                if (dialog.ShowDialog(this) != DialogResult.OK || dialog.Value.Length == 0 || dialog.Value == preset.Name) return;
                if (NameExists(dialog.Value, preset.Id)) { MessageBox.Show(this, "预设名称已存在。", "名称重复", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
                preset.Name = dialog.Value;
                _store.Save(_data);
                RefreshList();
                _list.SelectedItem = preset;
                _status.Text = "预设已重命名";
            }
        }

        private void DeleteSelected()
        {
            ColorPreset preset = _list.SelectedItem as ColorPreset;
            if (preset == null) return;
            if (MessageBox.Show(this, "删除预设“" + preset.Name + "”？", "确认删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            _data.Presets.Remove(preset);
            _store.Save(_data);
            RefreshList();
            _status.Text = "预设已删除";
        }

        private bool NameExists(string name, string exceptId)
        {
            for (int i = 0; i < _data.Presets.Count; i++)
                if (_data.Presets[i].Id != exceptId && String.Equals(_data.Presets[i].Name, name, StringComparison.CurrentCultureIgnoreCase)) return true;
            return false;
        }

        private void RegisterPresetHotkeys()
        {
            if (!IsHandleCreated) return;
            UnregisterPresetHotkeys();
            RegisterHotKey(Handle, PanelHotkeyId, ModControl | ModAlt, 0x30);
            int count = Math.Min(9, _data.Presets.Count);
            for (int i = 0; i < count; i++) RegisterHotKey(Handle, 1000 + i, ModControl | ModAlt, (uint)(0x31 + i));
        }

        private void UnregisterPresetHotkeys()
        {
            if (!IsHandleCreated) return;
            UnregisterHotKey(Handle, PanelHotkeyId);
            for (int i = 0; i < 9; i++) UnregisterHotKey(Handle, 1000 + i);
        }

        private void ShowWindow()
        {
            _allowVisible = true;
            Show();
            WindowState = FormWindowState.Normal;
            Activate();
        }

        private void ToggleWindow()
        {
            if (Visible)
            {
                Hide();
                return;
            }
            ShowWindow();
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_forceClose && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                return;
            }
        }

        private void ShowError(string title, Exception ex)
        {
            MessageBox.Show(this, ex.Message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
            _status.Text = title;
        }
    }
}
