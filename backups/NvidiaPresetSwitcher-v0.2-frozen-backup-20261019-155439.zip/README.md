# NVIDIA 颜色预设切换器

一个本地 Windows 工具，用于读取并保存 **NVIDIA App → 系统 → 颜色** 的当前状态，然后通过隐藏式工具面板或快捷键快速恢复预设。

## 当前功能

- 读取 NVIDIA 显示器的数字振动控制与色调。
- 读取并保存当前亮度、对比度、伽马数值，同时生成 NVIDIA 显示管线 LUT。
- 保存 NVIDIA 当前用户颜色参数，并在应用预设时重建显示管线 LUT。
- 新建、重命名、删除、应用任意数量的预设。
- 登录 Windows 后自动静默启动。
- 移除托盘图标，面板不进入任务栏或 `Alt+Tab` 窗口列表。
- `Ctrl+Alt+0` 显示或隐藏工具面板。
- 前九个预设对应 `Ctrl+Alt+1` 至 `Ctrl+Alt+9`。
- 预设仅保存在 `%APPDATA%\NvidiaPresetSwitcher\presets.json`，程序不联网。

## 使用方法

1. 在 NVIDIA App 中调整好游戏颜色。
2. 打开本工具，点击“保存当前为新预设”，命名为“游戏”等。
3. 回到 NVIDIA App 调整好工作颜色，再保存为“工作”。
4. 双击预设、点击“应用”或使用快捷键即可切换。
5. 点击窗口关闭按钮会隐藏面板；按 `Ctrl+Alt+0` 再次调出，或点击“退出程序”结束后台进程。

## 构建

在 PowerShell 中运行：

```powershell
.\build.ps1
```

生成文件位于 `outputs\NvidiaPresetSwitcher.exe`。

## 工作原理

- 数字振动控制与色调通过本机 NVIDIA 驱动的 NVAPI 读取和应用。
- 亮度、对比度和伽马从 NVIDIA App 使用的当前用户颜色参数读取，并通过 NVIDIA 显示管线 LUT 应用。
- 预设绑定到 NVIDIA 显示设备名称；显示器重排时会使用枚举序号进行兼容匹配。

## 运行要求

- Windows 10 或 Windows 11 x64
- NVIDIA GPU 与已安装的 NVIDIA 显示驱动
- .NET Framework 4.7.2 或更高版本
