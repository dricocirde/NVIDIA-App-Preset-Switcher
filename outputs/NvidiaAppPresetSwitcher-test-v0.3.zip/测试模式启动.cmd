@echo off
start "" "%~dp0NvidiaAppPresetSwitcher.exe" --no-system-changes
